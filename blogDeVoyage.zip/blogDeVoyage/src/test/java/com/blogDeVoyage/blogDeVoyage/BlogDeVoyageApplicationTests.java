package com.blogDeVoyage.blogDeVoyage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BlogDeVoyageApplicationTests {

	@Test
	void contextLoads() {
	}

}
